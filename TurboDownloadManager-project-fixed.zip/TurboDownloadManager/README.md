# Turbo Download Manager

Turbo Download Manager is a native Android IDM-style download manager for ordinary HTTP/HTTPS files. It uses Kotlin, Jetpack Compose, Material 3, OkHttp, Room, WorkManager, Coroutines, and a foreground download service.

## Features

- HTTP and HTTPS downloads
- Resume, pause, cancel, retry
- HTTP Range detection
- 1 / 2 / 4 / 8 parallel connections
- Automatic fallback to a single connection when ranges are unavailable or fail
- Background downloads through a foreground service
- Persistent Room download history
- Recovery after process/device restart where Android permits it
- Share Sheet support for shared text containing URLs
- Clipboard paste helper
- MediaStore Downloads/TurboDownloadManager storage
- Optional SAF destination folder
- Download search and sorting
- Speed display, ETA-ready data, and optional speed limiting
- Wi-Fi/mobile-data controls
- Light/dark/system theme
- Download and error notifications
- No Firebase, server, paid API, DRM bypass, or credential extraction

## Build with Android Studio

1. Install a current Android Studio release with JDK 17 support.
2. Open the `TurboDownloadManager` folder.
3. Let Gradle sync and download dependencies.
4. Connect an Android device or start an emulator with API 26+.
5. Press **Run** to install the debug build.

The project is configured for Android API 37, minimum API 26, Gradle 9.6, Android Gradle Plugin 9.4.0, and Kotlin 2.4.21.

## Build the APK with GitHub Actions

1. Create a new GitHub repository.
2. Upload all files from this project, keeping the `.github/workflows/build.yml` path intact.
3. Push the files to the `main` branch, or open **Actions** and run **Build Turbo Download Manager APK** manually.
4. Wait for the workflow to finish.
5. Open the completed workflow run.
6. Download the artifact named **TurboDownloadManager-debug.apk**.
7. Install the APK on an Android device.

The APK is produced at:

`app/build/outputs/apk/debug/TurboDownloadManager-debug.apk`

## Storage behavior

By default, completed files are stored in:

`Downloads/TurboDownloadManager/`

The app uses MediaStore and does not request broad legacy storage permission. Users can optionally choose another folder through Android's Storage Access Framework.

## Important download limitations

A download manager can improve utilization when a server supports independent byte ranges, but it cannot overcome the server's bandwidth limit, ISP/network limit, congestion, or a server-imposed connection limit. The app therefore uses at most the user-selected 8 connections and falls back safely when segmented downloading is not supported.

The app only handles ordinary accessible HTTP/HTTPS files. It does not bypass DRM, paywalls, authentication controls, or other access restrictions.
