# Room/OkHttp use reflection/code generation as needed; no custom rules are required for debug.
