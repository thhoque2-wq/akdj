package com.turbodownloadmanager.repository

import com.turbodownloadmanager.db.*
import kotlinx.coroutines.flow.Flow

class DownloadRepository(private val dao: DownloadDao) {
    val all: Flow<List<DownloadEntity>> = dao.observeAll()
    fun byStatus(s: DownloadStatus) = dao.observeStatus(s)
    suspend fun get(id: Long) = dao.get(id)
    suspend fun insert(item: DownloadEntity) = dao.insert(item)
    suspend fun update(item: DownloadEntity) = dao.update(item)
    suspend fun delete(id: Long) = dao.deleteById(id)
    suspend fun recoverable() = dao.recoverable()
}
