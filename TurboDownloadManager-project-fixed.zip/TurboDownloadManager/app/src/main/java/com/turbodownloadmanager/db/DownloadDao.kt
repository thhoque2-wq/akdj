package com.turbodownloadmanager.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun get(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED','DOWNLOADING','PAUSED','FAILED') ORDER BY createdAt ASC")
    suspend fun recoverable(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE status = :status ORDER BY createdAt DESC")
    fun observeStatus(status: DownloadStatus): Flow<List<DownloadEntity>>

    @Insert suspend fun insert(item: DownloadEntity): Long
    @Update suspend fun update(item: DownloadEntity)
    @Delete suspend fun delete(item: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("UPDATE downloads SET status = :status WHERE id = :id") suspend fun setStatus(id: Long, status: DownloadStatus)
}
