package com.turbodownloadmanager.download

import android.content.Context
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.turbodownloadmanager.data.SettingsStore
import com.turbodownloadmanager.db.DownloadEntity
import com.turbodownloadmanager.db.DownloadStatus
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.RandomAccessFile
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

class DownloadEngine(private val context: Context, private val settings: SettingsStore) {
    private val client = OkHttpClient.Builder()
        .followRedirects(true).followSslRedirects(true)
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true).build()

    data class Result(val total: Long, val downloaded: Long, val file: File, val mimeType: String?, val fileName: String)
    data class Progress(val downloaded: Long, val total: Long, val speed: Long)
    private data class Probe(val total: Long, val range: Boolean, val name: String?, val mime: String?, val etag: String?)

    suspend fun download(item: DownloadEntity, onProgress: suspend (Progress) -> Unit): Result = withContext(Dispatchers.IO) {
        val temp = File(item.tempPath ?: File(context.cacheDir, "downloads/${item.id}.part").path).apply { parentFile?.mkdirs() }
        val probe = probe(item.url, item.fileName)
        val total = if (probe.total > 0) probe.total else item.totalBytes
        val connections = if (probe.range && total > 0) item.connectionCount.coerceIn(1, 8) else 1
        if (connections > 1) {
            try {
                downloadParallel(item, probe, total, temp, connections, onProgress)
            } catch (e: DownloadException) {
                temp.delete()
                File(temp.parentFile, temp.name + ".meta").delete()
                downloadSingle(item, probe.copy(range = false), total, temp, onProgress)
            }
        } else {
            downloadSingle(item, probe, total, temp, onProgress)
        }
        if (total > 0 && temp.length() != total) throw DownloadException("Downloaded file size does not match the server's Content-Length.")
        Result(total, temp.length(), temp, probe.mime ?: item.mimeType, probe.name ?: item.fileName)
    }

    private fun probe(url: String, fallbackName: String): Probe {
        val head = runCatching {
            client.newCall(Request.Builder().url(url).head().build()).execute().use { r ->
                if (!r.isSuccessful && r.code !in 300..399) null else Triple(r.header("Content-Length")?.toLongOrNull() ?: -1, r.header("Content-Type"), r.header("ETag"))
            }
        }.getOrNull()
        var range = false
        var total = head?.first ?: -1
        var mime = head?.second
        var etag = head?.third
        runCatching {
            client.newCall(Request.Builder().url(url).header("Range", "bytes=0-0").build()).execute().use { r ->
                if (r.code == 206) {
                    range = true
                    val cr = r.header("Content-Range")
                    total = cr?.substringAfter('/')?.toLongOrNull() ?: total
                } else if (r.code == 200 && total <= 0) total = r.header("Content-Length")?.toLongOrNull() ?: -1
                if (mime == null) mime = r.header("Content-Type")
                if (etag == null) etag = r.header("ETag")
            }
        }
        val cd = head?.let { null }
        val name = filenameFromHeaders(url, fallbackName)
        return Probe(total, range, name, mime, etag)
    }

    private fun filenameFromHeaders(url: String, fallback: String): String {
        val req = Request.Builder().url(url).head().build()
        return runCatching {
            client.newCall(req).execute().use { response ->
                val disposition = response.header("Content-Disposition")
                val match = Regex("filename\\*?=(?:UTF-8''|\\\")?([^\\\";]+)", RegexOption.IGNORE_CASE).find(disposition ?: "")
                sanitize(match?.groupValues?.getOrNull(1)?.trim() ?: fallback.ifBlank { url.substringAfterLast('/').substringBefore('?') }.ifBlank { "download" })
            }
        }.getOrElse { sanitize(fallback.ifBlank { "download" }) }
    }

    private suspend fun downloadSingle(item: DownloadEntity, probe: Probe, total: Long, temp: File, onProgress: suspend (Progress) -> Unit) {
        var offset = if (temp.exists()) temp.length() else 0L
        val builder = Request.Builder().url(item.url)
        if (offset > 0) builder.header("Range", "bytes=$offset-")
        val response = client.newCall(builder.build()).execute()
        response.use { r ->
            if (r.code == 416) { temp.delete(); throw DownloadException("HTTP 416: the saved resume range is no longer valid.") }
            if (!r.isSuccessful) throw DownloadException(httpMessage(r.code, r.message))
            if (offset > 0 && r.code != 206) { offset = 0; temp.outputStream().use { it.flush() } }
            val body = r.body ?: throw DownloadException("Server returned an empty response.")
            if (offset == 0L) temp.outputStream().use { it.flush() }
            val raf = RandomAccessFile(temp, "rw")
            raf.seek(offset)
            body.byteStream().use { input ->
                val buffer = ByteArray(128 * 1024)
                var downloaded = offset
                var lastTime = System.nanoTime()
                var lastBytes = downloaded
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val n = input.read(buffer)
                    if (n < 0) break
                    raf.write(buffer, 0, n)
                    downloaded += n
                    val now = System.nanoTime()
                    if (now - lastTime >= 500_000_000) {
                        val speed = ((downloaded - lastBytes) * 1_000_000_000L / (now - lastTime)).coerceAtLeast(0)
                        onProgress(Progress(downloaded, total, speed))
                        lastTime = now; lastBytes = downloaded
                    }
                    throttle(n.toLong(), item.id)
                }
                onProgress(Progress(downloaded, total, 0))
            }
            raf.close()
        }
    }

    private suspend fun downloadParallel(item: DownloadEntity, probe: Probe, total: Long, temp: File, count: Int, onProgress: suspend (Progress) -> Unit) = coroutineScope {
        RandomAccessFile(temp, "rw").use { it.setLength(total) }
        val progress = LongArray(count)
        val meta = File(temp.parentFile, "${temp.name}.meta")
        loadProgress(meta, progress)
        val starts = LongArray(count) { i -> total * i / count }
        val ends = LongArray(count) { i -> total * (i + 1) / count - 1 }
        progress.forEachIndexed { i, v -> progress[i] = v.coerceIn(0, ends[i] - starts[i] + 1) }
        val mutex = Any()
        val started = System.nanoTime()
        var lastReport = started
        var lastTotal = progress.sum()
        val jobs = (0 until count).map { index ->
            async(Dispatchers.IO) {
                var done = progress[index]
                var cursor = starts[index] + done
                while (cursor <= ends[index]) {
                    currentCoroutineContext().ensureActive()
                    val end = ends[index]
                    val request = Request.Builder().url(item.url).header("Range", "bytes=$cursor-$end").build()
                    client.newCall(request).execute().use { response ->
                        if (response.code == 416) throw DownloadException("HTTP 416: the requested byte range is no longer valid.")
                        if (response.code != 206) throw DownloadException("Server stopped honoring byte ranges (HTTP ${response.code}).")
                        val body = response.body ?: throw DownloadException("Empty range response.")
                        RandomAccessFile(temp, "rw").use { raf ->
                            raf.seek(cursor)
                            body.byteStream().use { input ->
                                val buffer = ByteArray(64 * 1024)
                                while (true) {
                                    currentCoroutineContext().ensureActive()
                                    val n = input.read(buffer)
                                    if (n < 0) break
                                    raf.write(buffer, 0, n)
                                    cursor += n
                                    done += n
                                    progress[index] = done
                                    throttle(n.toLong(), item.id, count)
                                    val now = System.nanoTime()
                                    if (now - lastReport >= 500_000_000) synchronized(mutex) {
                                        val current = progress.sum()
                                        val speed = ((current - lastTotal) * 1_000_000_000L / (now - lastReport)).coerceAtLeast(0)
                                        lastReport = now; lastTotal = current
                                        runBlocking { onProgress(Progress(current, total, speed)) }
                                    }
                                }
                            }
                        }
                    }
                    saveProgress(meta, progress)
                }
            }
        }
        jobs.awaitAll()
        meta.delete()
        onProgress(Progress(total, total, 0))
    }

    private suspend fun throttle(bytes: Long, id: Long, connections: Int = 1) {
        val limit = settings.load().speedLimitBytes
        if (limit <= 0 || bytes <= 0) return
        val perConnection = max(1L, limit / connections)
        val millis = bytes * 1000L / perConnection
        if (millis > 2) delay(min(millis, 500L))
    }

    private fun loadProgress(file: File, out: LongArray) {
        if (!file.exists()) return
        runCatching { file.readLines().forEachIndexed { i, line -> if (i < out.size) out[i] = line.toLongOrNull() ?: 0 } }
    }
    private fun saveProgress(file: File, progress: LongArray) { runCatching { file.writeText(progress.joinToString("\n")) } }
    private fun sanitize(value: String): String = value.replace(Regex("[\\x00-\\x1F<>:\\"/\\\\|?*]"), "_").trim().ifBlank { "download" }.take(180)

    private fun httpMessage(code: Int, reason: String): String = when (code) {
        403 -> "HTTP 403: the server refused access to this file."
        404 -> "HTTP 404: the file was not found."
        408 -> "HTTP 408: the server timed out."
        429 -> "HTTP 429: too many requests; try again later."
        500, 502, 503, 504 -> "HTTP $code: the server is temporarily unavailable."
        else -> "HTTP $code: $reason"
    }

    class DownloadException(message: String) : Exception(message)
}
