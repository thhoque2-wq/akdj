package com.turbodownloadmanager.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import com.turbodownloadmanager.data.SettingsStore
import java.io.File

class FileManager(private val context: Context, private val settings: SettingsStore) {
    fun createFinal(name: String, mime: String?): Uri {
        val custom = settings.load().defaultFolderUri?.let(Uri::parse)
        if (custom != null) {
            return DocumentsContract.createDocument(context.contentResolver, custom, mime ?: "application/octet-stream", name)
                ?: error("Unable to create the selected destination file")
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime ?: "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TurboDownloadManager")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Unable to create destination file")
    }
    fun copyAndPublish(source: File, uri: Uri) {
        context.contentResolver.openOutputStream(uri, "w")?.use { output -> source.inputStream().use { it.copyTo(output, 128 * 1024) } }
            ?: error("Unable to open destination")
        runCatching { context.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null) }
    }
    fun delete(uri: String?) { uri?.let { runCatching { context.contentResolver.delete(Uri.parse(it), null, null) } } }
}
