package com.turbodownloadmanager.service

import android.app.Service
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.turbodownloadmanager.data.SettingsStore
import com.turbodownloadmanager.db.*
import com.turbodownloadmanager.download.DownloadEngine
import com.turbodownloadmanager.utils.FileManager
import com.turbodownloadmanager.utils.FormatUtils
import com.turbodownloadmanager.utils.NotificationHelper
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class DownloadForegroundService : Service() {
    companion object {
        const val ACTION_START = "com.turbodownloadmanager.START"
        const val ACTION_PAUSE = "com.turbodownloadmanager.PAUSE"
        const val ACTION_RESUME = "com.turbodownloadmanager.RESUME"
        const val ACTION_CANCEL = "com.turbodownloadmanager.CANCEL"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var dao: DownloadDao
    private lateinit var engine: DownloadEngine
    private lateinit var settings: SettingsStore
    private lateinit var files: FileManager
    private lateinit var notifications: NotificationHelper
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val speeds = ConcurrentHashMap<Long, Long>()

    override fun onCreate() {
        super.onCreate()
        dao = AppDatabase.get(this).downloadDao()
        settings = SettingsStore(this)
        engine = DownloadEngine(this, settings)
        files = FileManager(this, settings)
        notifications = NotificationHelper(this)
        startForeground(NotificationHelper.ID, notifications.notification(-1, "Turbo Download Manager", 0, "Ready", ACTION_PAUSE))
        scope.launch { dao.recoverable().filter { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING }.forEach { launchIfCapacity(it.id) } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getLongExtra(DownloadController.EXTRA_ID, -1L) ?: -1L
        when (intent?.action) {
            ACTION_START, ACTION_RESUME -> if (id > 0) scope.launch { dao.setStatus(id, DownloadStatus.QUEUED); launchIfCapacity(id) }
            ACTION_PAUSE -> if (id > 0) pause(id)
            ACTION_CANCEL -> if (id > 0) cancel(id)
        }
        return START_STICKY
    }

    private fun launchIfCapacity(id: Long) {
        if (jobs.containsKey(id)) return
        scope.launch {
            while (jobs.size >= settings.load().maxSimultaneous) delay(500)
            val item = dao.get(id) ?: return@launch
            if (item.status == DownloadStatus.COMPLETED || item.status == DownloadStatus.CANCELLED) return@launch
            val job = launch(start = CoroutineStart.LAZY) { runDownload(item) }
            jobs[id] = job
            job.invokeOnCompletion { jobs.remove(id); speeds.remove(id); scope.launch { launchNext() } }
            job.start()
        }
    }

    private suspend fun launchNext() {
        val max = settings.load().maxSimultaneous
        if (jobs.size >= max) return
        dao.recoverable().filter { it.status == DownloadStatus.QUEUED }.take(max - jobs.size).forEach { launchIfCapacity(it.id) }
    }

    private suspend fun runDownload(item: DownloadEntity) {
        try {
            if (!networkAllowed()) { dao.update(item.copy(status = DownloadStatus.QUEUED, errorMessage = "Waiting for an allowed network.")); return }
            dao.update(item.copy(status = DownloadStatus.DOWNLOADING, errorMessage = null))
            val result = engine.download(item.copy(status = DownloadStatus.DOWNLOADING), onProgress = { p ->
                speeds[item.id] = p.speed
                val latest = dao.get(item.id) ?: return@download
                dao.update(latest.copy(downloadedBytes = p.downloaded, totalBytes = p.total, speed = p.speed, status = DownloadStatus.DOWNLOADING, tempPath = resultTemp(item)))
                updateNotification(latest.id, latest.fileName, p)
            })
            val uri = files.createFinal(result.fileName, result.mimeType)
            try {
                files.copyAndPublish(result.file, uri)
            } catch (t: Throwable) {
                files.delete(uri.toString()); throw t
            }
            result.file.delete()
            File(result.file.parentFile, result.file.name + ".meta").delete()
            val latest = dao.get(item.id) ?: return
            dao.update(latest.copy(fileName = result.fileName, mimeType = result.mimeType, totalBytes = result.total, downloadedBytes = result.downloaded, localUri = uri.toString(), localPath = "Download/TurboDownloadManager/${result.fileName}", tempPath = null, speed = 0, status = DownloadStatus.COMPLETED, completedAt = System.currentTimeMillis(), errorMessage = null))
            updateNotification(item.id, result.fileName, DownloadEngine.Progress(result.total, result.total, 0))
            if (settings.load().completionNotification) getSystemService(android.app.NotificationManager::class.java).notify((5000 + item.id).toInt(), notifications.completion(result.fileName, item.id))
        } catch (ce: CancellationException) {
            val current = dao.get(item.id)
            if (current?.status != DownloadStatus.PAUSED && current?.status != DownloadStatus.CANCELLED) dao.update(current!!.copy(status = DownloadStatus.FAILED, errorMessage = "Download interrupted."))
            throw ce
        } catch (t: Throwable) {
            val current = dao.get(item.id) ?: return
            if (current.status == DownloadStatus.PAUSED || current.status == DownloadStatus.CANCELLED) return
            val settingsNow = settings.load()
            if (settingsNow.autoRetry && current.retryCount < settingsNow.maxRetries) {
                val retry = current.copy(status = DownloadStatus.QUEUED, retryCount = current.retryCount + 1, errorMessage = t.message ?: "Temporary network error", speed = 0)
                dao.update(retry)
                delay((1000L * (1L shl minOf(retry.retryCount, 5))).coerceAtMost(30_000L))
                runDownload(retry)
            } else {
                dao.update(current.copy(status = DownloadStatus.FAILED, errorMessage = t.message ?: "Unknown download error", speed = 0))
                updateNotification(current.id, current.fileName, DownloadEngine.Progress(current.downloadedBytes, current.totalBytes, 0))
                if (settingsNow.errorNotification) getSystemService(android.app.NotificationManager::class.java).notify((6000 + current.id).toInt(), notifications.error(current.fileName, current.errorMessage ?: "Unknown error"))
            }
        }
    }

    private fun resultTemp(item: DownloadEntity): String = item.tempPath ?: File(cacheDir, "downloads/${item.id}.part").path

    private fun pause(id: Long) {
        scope.launch {
            dao.get(id)?.let { dao.update(it.copy(status = DownloadStatus.PAUSED, speed = 0)) }
            jobs[id]?.cancel()
        }
    }
    private fun cancel(id: Long) {
        scope.launch {
            dao.get(id)?.let { item ->
                dao.update(item.copy(status = DownloadStatus.CANCELLED, speed = 0))
                jobs[id]?.cancelAndJoin()
                item.tempPath?.let { File(it).delete() }
                File(cacheDir, "downloads/${id}.part").delete()
                File(cacheDir, "downloads/${id}.part.meta").delete()
                item.localUri?.let(files::delete)
                dao.get(id)?.let { latest -> dao.update(latest.copy(status = DownloadStatus.CANCELLED, downloadedBytes = 0, speed = 0)) }
            }
        }
    }

    private fun updateNotification(id: Long, name: String, p: DownloadEngine.Progress) {
        val percent = if (p.total > 0) ((p.downloaded * 100) / p.total).toInt() else -1
        val n = notifications.notification(id, name, percent, FormatUtils.speed(p.speed), ACTION_PAUSE)
        getSystemService(android.app.NotificationManager::class.java).notify(NotificationHelper.ID, n)
    }

    private fun networkAllowed(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        val s = settings.load()
        val wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        return (!s.wifiOnly && s.allowMobileData) || wifi
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
