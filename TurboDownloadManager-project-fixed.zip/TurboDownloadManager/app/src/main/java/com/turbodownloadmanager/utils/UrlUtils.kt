package com.turbodownloadmanager.utils

import android.webkit.URLUtil

object UrlUtils {
    private val urlRegex = Regex("https?://[^\\s<>\\\"']+", RegexOption.IGNORE_CASE)
    fun extractUrl(text: String): String? = urlRegex.find(text)?.value?.trimEnd('.', ',', ')', ']', '}', '"', '\'')
    fun normalize(text: String): String? {
        val value = extractUrl(text.trim()) ?: text.trim().takeIf { it.startsWith("http://") || it.startsWith("https://") }
        return value?.takeIf { URLUtil.isValidUrl(it) && (it.startsWith("http://") || it.startsWith("https://")) }
    }
}
